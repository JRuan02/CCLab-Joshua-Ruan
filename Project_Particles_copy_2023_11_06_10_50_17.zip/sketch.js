let particles = [];

function setup() {
  createCanvas(600, 500);
  background(100);
}

function draw() {
  background(100);

  // generate
  particles.push(new Particle(0, 0, random(-2, 2), random(-2, 2)));
  particles.push(new Particle(width, 0, random(-2, 2), random(-2, 2)));
  particles.push(new Particle(0, height, random(-2, 2), random(-2, 2)));
  particles.push(new Particle(width, height, random(-2, 2), random(-2, 2)));

  // update and display
  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    p.move();
    p.checkEdges();
    p.display();
  }

  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    if (p.isDone == true) {
      particles.splice(i, 1); 
    }
  }

  // Limiting particles (Prof Moon Notes)
  while (particles.length > 1000) {
    particles.splice(0, 1); 
  }

  noStroke();
  fill(0, 255, 0);
  text(particles.length, 10, 20);
}

class Particle {
  constructor(startX, startY, startSpeedX, startSpeedY) {
    this.x = startX;
    this.y = startY;
    this.speedX = startSpeedX;
    this.speedY = startSpeedY;
    this.isDone = false;
  }
  move() {
    this.x += this.speedX;
    this.y += this.speedY;
  }
  checkEdges() {
    if (this.x < 0 || this.x > width) {
      this.isDone = true;
    }
    if (this.y < 0 || this.y > height) {
      this.isDone = true;
    }
  }
  display() {
    push();
    translate(this.x, this.y);
    rotate(atan2(this.speedY, this.speedX));
    noStroke();
    fill(0);
    triangle(-20, -10, -20, 10, 0, 0);
    pop();
  }
}